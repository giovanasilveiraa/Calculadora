﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prj1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnMediaNumerica_Click(object sender, EventArgs e)
        {

            try
            {
                double a = Convert.ToDouble(txtA.Text);
                double b = Convert.ToDouble(txtB.Text);
                double m = (a + b) / 2;
                lblResposta.Text = "Media = '" + m.ToString("N6");
                string item = String.Format("Media {0} e {1} = {2}", a, b, m);
                lstHistorico.Items.Add(item);
            }
            catch (Exception)
            {
                
                MessageBox.Show("Valor Incorreto!");
            }
            
        }


        private void txtA_KeyPress(object sender, KeyPressEventArgs e)
        {

            tecladoNumerico (sender, e, txtA);

        }

        private void txtB_KeyPress(object sender, KeyPressEventArgs e)
        {
            tecladoNumerico (sender, e, txtB);
  
        }

        private void tecladoNumerico(object sender, KeyPressEventArgs e, TextBox p)
        {
            char tecla = e.KeyChar;

            if (Char.IsLetter(tecla))
            {
                e.Handled = true;
            }
            if (tecla == '.')
            {
                e.KeyChar = ',';
            }
            if (p.Text.Contains(",") && e.KeyChar == ',')
            {
                e.Handled = true;
            }
            if (Char.IsPunctuation(tecla) && tecla != ',')
            {
                e.Handled = true;
            }
            if (tecla == '+' || tecla == '=')
            {
                e.Handled = true;
            }

        }

        private void txtA_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtA.Text.Equals(""))
            {
                txtA.Text = "0";
                txtA.SelectAll();
            }
        }

        private void txtB_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtB.Text.Equals(""))
            {
                txtB.Text = "0";
                txtB.SelectAll();
            }
            if (e.KeyCode == Keys.Enter)
            {
                btnMediaNumerica_Click(sender, e);
                txtB.Focus();
                txtB.SelectAll();
            }
        }

        private void btnMediaGeometrica_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(txtA.Text);
                double b = Convert.ToDouble(txtB.Text);
                double m = Math.Sqrt(a * b);
                lblResposta.Text = "Media Geométrica = " + m.ToString("N6");
                string item = String.Format("Media Geométrica {0} e {1} = {2}", a, b, m);
                lstHistorico.Items.Add(item);
            }
            catch (Exception)
            {

                MessageBox.Show("Valor Incorreto!");
            }
        }

        private void txtA_Click(object sender, EventArgs e)
        {
            txtA.SelectAll();
        }

        private void txtB_Click(object sender, EventArgs e)
        {
            txtB.SelectAll();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstHistorico.Items.Clear();
        }
    }
}
