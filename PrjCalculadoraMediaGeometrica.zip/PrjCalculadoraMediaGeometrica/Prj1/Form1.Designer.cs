﻿namespace Prj1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnMediaNumerica = new System.Windows.Forms.Button();
            this.lblResposta = new System.Windows.Forms.Label();
            this.btnMediaGeometrica = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lstHistorico = new System.Windows.Forms.ListBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Digite o valor de A";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(13, 30);
            this.txtA.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtA.MaxLength = 15;
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(320, 25);
            this.txtA.TabIndex = 1;
            this.txtA.Text = "0";
            this.txtA.Click += new System.EventHandler(this.txtA_Click);
            this.txtA.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.txtA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtA_KeyPress);
            this.txtA.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtA_KeyUp);
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(13, 97);
            this.txtB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtB.MaxLength = 15;
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(319, 25);
            this.txtB.TabIndex = 2;
            this.txtB.Text = "0";
            this.txtB.Click += new System.EventHandler(this.txtB_Click);
            this.txtB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtB_KeyPress);
            this.txtB.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtB_KeyUp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label2.Location = new System.Drawing.Point(15, 77);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Digite o valor de B\r\n";
            // 
            // btnMediaNumerica
            // 
            this.btnMediaNumerica.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnMediaNumerica.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMediaNumerica.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnMediaNumerica.Location = new System.Drawing.Point(12, 151);
            this.btnMediaNumerica.Name = "btnMediaNumerica";
            this.btnMediaNumerica.Size = new System.Drawing.Size(319, 40);
            this.btnMediaNumerica.TabIndex = 3;
            this.btnMediaNumerica.Text = "CALCULAR MÉDIA";
            this.btnMediaNumerica.UseVisualStyleBackColor = false;
            this.btnMediaNumerica.Click += new System.EventHandler(this.btnMediaNumerica_Click);
            // 
            // lblResposta
            // 
            this.lblResposta.BackColor = System.Drawing.Color.LightSkyBlue;
            this.lblResposta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResposta.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResposta.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblResposta.Location = new System.Drawing.Point(11, 263);
            this.lblResposta.Name = "lblResposta";
            this.lblResposta.Size = new System.Drawing.Size(320, 40);
            this.lblResposta.TabIndex = 4;
            this.lblResposta.Text = "RESPOSTA";
            this.lblResposta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnMediaGeometrica
            // 
            this.btnMediaGeometrica.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnMediaGeometrica.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMediaGeometrica.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnMediaGeometrica.Location = new System.Drawing.Point(14, 208);
            this.btnMediaGeometrica.Name = "btnMediaGeometrica";
            this.btnMediaGeometrica.Size = new System.Drawing.Size(319, 40);
            this.btnMediaGeometrica.TabIndex = 3;
            this.btnMediaGeometrica.Text = "CALCULAR MÉDIA GEOMÉTRICA";
            this.btnMediaGeometrica.UseVisualStyleBackColor = false;
            this.btnMediaGeometrica.Click += new System.EventHandler(this.btnMediaGeometrica_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label3.Location = new System.Drawing.Point(480, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "HISTÓRICO";
            // 
            // lstHistorico
            // 
            this.lstHistorico.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstHistorico.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lstHistorico.FormattingEnabled = true;
            this.lstHistorico.ItemHeight = 20;
            this.lstHistorico.Location = new System.Drawing.Point(393, 33);
            this.lstHistorico.Name = "lstHistorico";
            this.lstHistorico.Size = new System.Drawing.Size(276, 224);
            this.lstHistorico.TabIndex = 6;
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnLimpar.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnLimpar.Location = new System.Drawing.Point(393, 270);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(276, 40);
            this.btnLimpar.TabIndex = 3;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(205)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(681, 322);
            this.Controls.Add(this.lstHistorico);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblResposta);
            this.Controls.Add(this.btnMediaGeometrica);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnMediaNumerica);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PROGRAMA MÉDIA";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnMediaNumerica;
        private System.Windows.Forms.Label lblResposta;
        private System.Windows.Forms.Button btnMediaGeometrica;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lstHistorico;
        private System.Windows.Forms.Button btnLimpar;
    }
}

